import React, { Component } from "react";
import { Radio } from "antd";

export class Basic extends Component {
  render() {
    return <Radio>Radio</Radio>;
  }
}

export default Basic;
