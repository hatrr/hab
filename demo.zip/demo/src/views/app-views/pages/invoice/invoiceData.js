export const invoiceData = [
	{
		key: "1",
		product: "Samsung Galaxy S20+",
		quantity: 2,
		price: 899.00
	},
	{
		key: "2",
		product: "SonicGear Evo 9 BTMI Speaker",
		quantity: 1,
		price: 199.00
	},
	{
		key: "3",
		product: "Sharp Aquos 40-Inch Easy Smart LED TV",
		quantity: 1,
		price: 977.00
	},
]